# PedidoStatus API (C# / .NET)

Este projeto implementa o desafio com **2 endpoints**:

1) **Pedido**: CRUD em `/api/pedido` (GET, POST, PUT, DELETE) com persistência em **EF Core InMemory**.
2) **Mudança de Status**: POST em `/api/status` que avalia regras e retorna uma lista de status (sem persistir status).

## Requisitos

- .NET SDK **8.0+** instalado

## Como rodar

Na raiz do projeto (onde está este `instructions.md`):

```bash
# restaurar dependências
cd src/Api
dotnet restore

# rodar a API
dotnet run
```

A API sobe por padrão em uma porta local e expõe Swagger em:

- `http://localhost:{porta}/swagger`

> Observação: a porta exata aparece no console do `dotnet run`.

## Como executar os testes

```bash
cd tests/Api.Tests
dotnet test
```

Os testes cobrem os cenários #1 a #6 da especificação (StatusService).

## Endpoints

### 1) Pedido (CRUD)

Base URL: `http://localhost:{porta}/api/pedido`

#### POST /api/pedido

```json
{
  "pedido":"123456",
  "itens": [
    {"descricao":"Item A","precoUnitario":10,"qtd":1},
    {"descricao":"Item B","precoUnitario":5,"qtd":2}
  ]
}
```

#### GET /api/pedido
Retorna todos os pedidos.

#### GET /api/pedido/{codigo}
Retorna um pedido pelo código.

#### PUT /api/pedido/{codigo}
Atualiza o pedido (substitui itens). O `codigo` da rota deve ser igual ao `pedido` no payload.

#### DELETE /api/pedido/{codigo}
Remove o pedido.

### 2) Status

POST `http://localhost:{porta}/api/status`

Payload:

```json
{
  "status":"APROVADO",
  "itensAprovados":3,
  "valorAprovado":20,
  "pedido":"123456"
}
```

Response:

```json
{
  "pedido":"123456",
  "status": ["APROVADO"]
}
```

## Regras implementadas

- Se o **pedido não existe**: `CODIGO_PEDIDO_INVALIDO`
- Se `status == REPROVADO`: `REPROVADO`
- Se `status == APROVADO`:
  - Se `itensAprovados == soma(qtd)` **e** `valorAprovado == soma(precoUnitario*qtd)`: `APROVADO`
  - Se `valorAprovado < total`: `APROVADO_VALOR_A_MENOR`
  - Se `valorAprovado > total`: `APROVADO_VALOR_A_MAIOR`
  - Se `itensAprovados < totalQtd`: `APROVADO_QTD_A_MENOR`
  - Se `itensAprovados > totalQtd`: `APROVADO_QTD_A_MAIOR`

> Quando for `APROVADO` exato, a API retorna **somente** `["APROVADO"]` (igual aos exemplos). Caso contrário, retorna todas as discrepâncias geradas.

## Exemplos cURL

### Criar pedido

```bash
curl -X POST "http://localhost:{porta}/api/pedido" \
  -H "Content-Type: application/json" \
  -d '{"pedido":"123456","itens":[{"descricao":"Item A","precoUnitario":10,"qtd":1},{"descricao":"Item B","precoUnitario":5,"qtd":2}]}'
```

### Avaliar status

```bash
curl -X POST "http://localhost:{porta}/api/status" \
  -H "Content-Type: application/json" \
  -d '{"status":"APROVADO","itensAprovados":4,"valorAprovado":21,"pedido":"123456"}'
```

