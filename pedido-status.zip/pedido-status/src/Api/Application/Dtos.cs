namespace Api.Application;

public record ItemPedidoDto(string descricao, decimal precoUnitario, int qtd);
public record PedidoDto(string pedido, List<ItemPedidoDto> itens);

public record StatusRequestDto(string status, int itensAprovados, decimal valorAprovado, string pedido);
public record StatusResponseDto(string pedido, List<string> status);
