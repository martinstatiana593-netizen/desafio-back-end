using Api.Domain;
using Api.Infrastructure;

namespace Api.Application;

public interface IPedidoService
{
    Task<List<PedidoDto>> GetAllAsync(CancellationToken ct);
    Task<PedidoDto?> GetByCodigoAsync(string codigo, CancellationToken ct);
    Task CreateAsync(PedidoDto dto, CancellationToken ct);
    Task UpdateAsync(string codigo, PedidoDto dto, CancellationToken ct);
    Task DeleteAsync(string codigo, CancellationToken ct);
}

public class PedidoService : IPedidoService
{
    private readonly IPedidoRepository _repo;

    public PedidoService(IPedidoRepository repo) => _repo = repo;

    public async Task<List<PedidoDto>> GetAllAsync(CancellationToken ct)
    {
        var all = await _repo.GetAllAsync(ct);
        return all.Select(Map).ToList();
    }

    public async Task<PedidoDto?> GetByCodigoAsync(string codigo, CancellationToken ct)
    {
        var p = await _repo.GetByCodigoAsync(codigo, ct);
        return p is null ? null : Map(p);
    }

    public async Task CreateAsync(PedidoDto dto, CancellationToken ct)
    {
        Validation.ValidatePedido(dto);

        var existente = await _repo.GetByCodigoAsync(dto.pedido, ct);
        if (existente is not null)
            throw new ArgumentException("pedido já existe");

        await _repo.AddAsync(Map(dto), ct);
    }

    public async Task UpdateAsync(string codigo, PedidoDto dto, CancellationToken ct)
    {
        Validation.ValidatePedido(dto);
        if (!string.Equals(codigo, dto.pedido, StringComparison.Ordinal))
            throw new ArgumentException("código na rota difere do payload");

        await _repo.UpdateAsync(Map(dto), ct);
    }

    public Task DeleteAsync(string codigo, CancellationToken ct) =>
        _repo.DeleteAsync(codigo, ct);

    private static Pedido Map(PedidoDto dto)
    {
        var pedido = new Pedido
        {
            Codigo = dto.pedido,
            Itens = dto.itens.Select(i => new ItemPedido
            {
                Descricao = i.descricao,
                PrecoUnitario = i.precoUnitario,
                Qtd = i.qtd
            }).ToList()
        };

        // assign FK on items
        foreach (var item in pedido.Itens)
            item.PedidoId = pedido.Id;

        return pedido;
    }

    private static PedidoDto Map(Pedido p) =>
        new(p.Codigo, p.Itens.Select(i => new ItemPedidoDto(i.Descricao, i.PrecoUnitario, i.Qtd)).ToList());
}
