using Api.Domain;

namespace Api.Application;

public interface IStatusRule
{
    void Apply(StatusContext ctx, List<string> output);
}

public sealed class StatusContext
{
    public required Pedido Pedido { get; init; }
    public required StatusRequestDto Request { get; init; }

    // Spec implies quantity is SUM(qtd)
    public int TotalQtd => Pedido.QuantidadeTotalItens();
    public decimal TotalValor => Pedido.ValorTotal();
}

public class AprovadoExatoRule : IStatusRule
{
    public void Apply(StatusContext ctx, List<string> output)
    {
        if (!ctx.Request.status.Equals("APROVADO", StringComparison.OrdinalIgnoreCase)) return;

        if (ctx.Request.itensAprovados == ctx.TotalQtd && ctx.Request.valorAprovado == ctx.TotalValor)
            output.Add("APROVADO");
    }
}

public class AprovadoValorMenorRule : IStatusRule
{
    public void Apply(StatusContext ctx, List<string> output)
    {
        if (!ctx.Request.status.Equals("APROVADO", StringComparison.OrdinalIgnoreCase)) return;

        if (ctx.Request.valorAprovado < ctx.TotalValor)
            output.Add("APROVADO_VALOR_A_MENOR");
    }
}

public class AprovadoValorMaiorRule : IStatusRule
{
    public void Apply(StatusContext ctx, List<string> output)
    {
        if (!ctx.Request.status.Equals("APROVADO", StringComparison.OrdinalIgnoreCase)) return;

        if (ctx.Request.valorAprovado > ctx.TotalValor)
            output.Add("APROVADO_VALOR_A_MAIOR");
    }
}

public class AprovadoQtdMenorRule : IStatusRule
{
    public void Apply(StatusContext ctx, List<string> output)
    {
        if (!ctx.Request.status.Equals("APROVADO", StringComparison.OrdinalIgnoreCase)) return;

        if (ctx.Request.itensAprovados < ctx.TotalQtd)
            output.Add("APROVADO_QTD_A_MENOR");
    }
}

public class AprovadoQtdMaiorRule : IStatusRule
{
    public void Apply(StatusContext ctx, List<string> output)
    {
        if (!ctx.Request.status.Equals("APROVADO", StringComparison.OrdinalIgnoreCase)) return;

        if (ctx.Request.itensAprovados > ctx.TotalQtd)
            output.Add("APROVADO_QTD_A_MAIOR");
    }
}
