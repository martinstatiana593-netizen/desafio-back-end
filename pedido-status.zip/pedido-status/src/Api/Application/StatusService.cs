using Api.Infrastructure;

namespace Api.Application;

public interface IStatusService
{
    Task<StatusResponseDto> AvaliarAsync(StatusRequestDto req, CancellationToken ct);
}

public class StatusService : IStatusService
{
    private readonly IPedidoRepository _repo;
    private readonly IReadOnlyList<IStatusRule> _rules;

    public StatusService(IPedidoRepository repo, IEnumerable<IStatusRule> rules)
    {
        _repo = repo;
        _rules = rules.ToList();
    }

    public async Task<StatusResponseDto> AvaliarAsync(StatusRequestDto req, CancellationToken ct)
    {
        Validation.ValidateStatusRequest(req);

        var pedido = await _repo.GetByCodigoAsync(req.pedido, ct);
        if (pedido is null)
            return new StatusResponseDto(req.pedido, new() { "CODIGO_PEDIDO_INVALIDO" });

        if (req.status.Equals("REPROVADO", StringComparison.OrdinalIgnoreCase))
            return new StatusResponseDto(req.pedido, new() { "REPROVADO" });

        if (!req.status.Equals("APROVADO", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("status deve ser APROVADO ou REPROVADO");

        var ctx = new StatusContext { Pedido = pedido, Request = req };
        var output = new List<string>();

        foreach (var rule in _rules)
            rule.Apply(ctx, output);

        // If exact, return ONLY APROVADO (matches examples)
        if (output.Contains("APROVADO"))
            return new StatusResponseDto(req.pedido, new() { "APROVADO" });

        return new StatusResponseDto(req.pedido, output.Distinct().ToList());
    }
}
