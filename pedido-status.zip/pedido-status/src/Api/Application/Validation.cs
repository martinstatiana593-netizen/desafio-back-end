namespace Api.Application;

public static class Validation
{
    public static void ValidatePedido(PedidoDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.pedido))
            throw new ArgumentException("pedido é obrigatório");

        if (dto.itens is null || dto.itens.Count == 0)
            throw new ArgumentException("itens deve ter pelo menos 1 item");

        foreach (var i in dto.itens)
        {
            if (string.IsNullOrWhiteSpace(i.descricao))
                throw new ArgumentException("descricao é obrigatória");

            if (i.precoUnitario < 0)
                throw new ArgumentException("precoUnitario não pode ser negativo");

            if (i.qtd <= 0)
                throw new ArgumentException("qtd deve ser maior que 0");
        }
    }

    public static void ValidateStatusRequest(StatusRequestDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.pedido))
            throw new ArgumentException("pedido é obrigatório");

        if (string.IsNullOrWhiteSpace(dto.status))
            throw new ArgumentException("status é obrigatório");

        if (dto.itensAprovados < 0)
            throw new ArgumentException("itensAprovados não pode ser negativo");

        if (dto.valorAprovado < 0)
            throw new ArgumentException("valorAprovado não pode ser negativo");
    }
}
