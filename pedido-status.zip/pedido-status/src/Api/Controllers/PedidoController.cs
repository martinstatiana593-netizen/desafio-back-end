using Api.Application;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

[ApiController]
[Route("api/pedido")]
public class PedidoController : ControllerBase
{
    private readonly IPedidoService _service;

    public PedidoController(IPedidoService service) => _service = service;

    [HttpGet]
    public async Task<ActionResult<List<PedidoDto>>> GetAll(CancellationToken ct) =>
        Ok(await _service.GetAllAsync(ct));

    [HttpGet("{codigo}")]
    public async Task<ActionResult<PedidoDto>> GetByCodigo(string codigo, CancellationToken ct)
    {
        var p = await _service.GetByCodigoAsync(codigo, ct);
        return p is null ? NotFound() : Ok(p);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] PedidoDto dto, CancellationToken ct)
    {
        await _service.CreateAsync(dto, ct);
        return CreatedAtAction(nameof(GetByCodigo), new { codigo = dto.pedido }, dto);
    }

    [HttpPut("{codigo}")]
    public async Task<IActionResult> Update(string codigo, [FromBody] PedidoDto dto, CancellationToken ct)
    {
        await _service.UpdateAsync(codigo, dto, ct);
        return NoContent();
    }

    [HttpDelete("{codigo}")]
    public async Task<IActionResult> Delete(string codigo, CancellationToken ct)
    {
        await _service.DeleteAsync(codigo, ct);
        return NoContent();
    }
}
