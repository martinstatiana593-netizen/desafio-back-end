using Api.Application;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers;

[ApiController]
[Route("api/status")]
public class StatusController : ControllerBase
{
    private readonly IStatusService _service;

    public StatusController(IStatusService service) => _service = service;

    [HttpPost]
    public async Task<ActionResult<StatusResponseDto>> Post([FromBody] StatusRequestDto req, CancellationToken ct)
    {
        var res = await _service.AvaliarAsync(req, ct);
        return Ok(res);
    }
}
