namespace Api.Domain;

public class Pedido
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Codigo { get; set; } = default!;

    public List<ItemPedido> Itens { get; set; } = new();

    public int QuantidadeTotalItens() => Itens.Sum(i => i.Qtd);
    public decimal ValorTotal() => Itens.Sum(i => i.PrecoUnitario * i.Qtd);
}

public class ItemPedido
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid PedidoId { get; set; }

    public string Descricao { get; set; } = default!;
    public decimal PrecoUnitario { get; set; }
    public int Qtd { get; set; }

    public Pedido? Pedido { get; set; }
}
