using Api.Domain;
using Microsoft.EntityFrameworkCore;

namespace Api.Infrastructure;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Pedido> Pedidos => Set<Pedido>();
    public DbSet<ItemPedido> Itens => Set<ItemPedido>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Pedido>(b =>
        {
            b.HasKey(p => p.Id);
            b.Property(p => p.Codigo).IsRequired();
            b.HasIndex(p => p.Codigo).IsUnique();

            b.HasMany(p => p.Itens)
                .WithOne(i => i.Pedido!)
                .HasForeignKey(i => i.PedidoId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<ItemPedido>(b =>
        {
            b.HasKey(i => i.Id);
            b.Property(i => i.Descricao).IsRequired();
            b.Property(i => i.PrecoUnitario).HasPrecision(18, 2);
            b.Property(i => i.Qtd).IsRequired();
        });
    }
}
