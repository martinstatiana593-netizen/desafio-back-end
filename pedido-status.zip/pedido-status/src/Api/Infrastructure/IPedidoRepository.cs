using Api.Domain;

namespace Api.Infrastructure;

public interface IPedidoRepository
{
    Task<Pedido?> GetByCodigoAsync(string codigo, CancellationToken ct);
    Task<List<Pedido>> GetAllAsync(CancellationToken ct);
    Task AddAsync(Pedido pedido, CancellationToken ct);
    Task UpdateAsync(Pedido pedido, CancellationToken ct);
    Task DeleteAsync(string codigo, CancellationToken ct);
}
