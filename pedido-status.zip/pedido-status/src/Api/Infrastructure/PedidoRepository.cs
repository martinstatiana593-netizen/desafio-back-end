using Api.Domain;
using Microsoft.EntityFrameworkCore;

namespace Api.Infrastructure;

public class PedidoRepository : IPedidoRepository
{
    private readonly AppDbContext _db;

    public PedidoRepository(AppDbContext db) => _db = db;

    public Task<List<Pedido>> GetAllAsync(CancellationToken ct) =>
        _db.Pedidos.Include(p => p.Itens).AsNoTracking().ToListAsync(ct);

    public Task<Pedido?> GetByCodigoAsync(string codigo, CancellationToken ct) =>
        _db.Pedidos.Include(p => p.Itens).FirstOrDefaultAsync(p => p.Codigo == codigo, ct);

    public async Task AddAsync(Pedido pedido, CancellationToken ct)
    {
        _db.Pedidos.Add(pedido);
        await _db.SaveChangesAsync(ct);
    }

    public async Task UpdateAsync(Pedido pedido, CancellationToken ct)
    {
        var existente = await _db.Pedidos.Include(p => p.Itens)
            .FirstOrDefaultAsync(p => p.Codigo == pedido.Codigo, ct);

        if (existente is null) return;

        // Replace items atomically (simple + deterministic)
        _db.Itens.RemoveRange(existente.Itens);
        existente.Itens = pedido.Itens;

        await _db.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(string codigo, CancellationToken ct)
    {
        var existente = await _db.Pedidos.FirstOrDefaultAsync(p => p.Codigo == codigo, ct);
        if (existente is null) return;

        _db.Pedidos.Remove(existente);
        await _db.SaveChangesAsync(ct);
    }
}
