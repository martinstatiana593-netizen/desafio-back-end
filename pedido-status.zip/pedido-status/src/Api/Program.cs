using Api.Application;
using Api.Infrastructure;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// In-memory database (self contained)
builder.Services.AddDbContext<AppDbContext>(o =>
    o.UseInMemoryDatabase("PedidosDb"));

// DI
builder.Services.AddScoped<IPedidoRepository, PedidoRepository>();
builder.Services.AddScoped<IPedidoService, PedidoService>();
builder.Services.AddScoped<IStatusService, StatusService>();

// Rules (evaluated for APROVADO)
builder.Services.AddScoped<IStatusRule, AprovadoExatoRule>();
builder.Services.AddScoped<IStatusRule, AprovadoValorMenorRule>();
builder.Services.AddScoped<IStatusRule, AprovadoValorMaiorRule>();
builder.Services.AddScoped<IStatusRule, AprovadoQtdMenorRule>();
builder.Services.AddScoped<IStatusRule, AprovadoQtdMaiorRule>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();

app.Run();

// For integration tests
public partial class Program { }
