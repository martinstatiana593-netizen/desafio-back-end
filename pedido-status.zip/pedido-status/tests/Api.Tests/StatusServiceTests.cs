using Api.Application;
using Api.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Api.Tests;

public class StatusServiceTests
{
    private static (StatusService svc, PedidoService pedidoSvc) Build()
    {
        var opts = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;

        var db = new AppDbContext(opts);
        var repo = new PedidoRepository(db);

        var rules = new IStatusRule[]
        {
            new AprovadoExatoRule(),
            new AprovadoValorMenorRule(),
            new AprovadoValorMaiorRule(),
            new AprovadoQtdMenorRule(),
            new AprovadoQtdMaiorRule(),
        };

        var statusSvc = new StatusService(repo, rules);
        var pedidoSvc = new PedidoService(repo);
        return (statusSvc, pedidoSvc);
    }

    private static PedidoDto PedidoPadrao() => new(
        "123456",
        new()
        {
            new("Item A", 10m, 1),
            new("Item B", 5m, 2),
        }
    );

    [Fact]
    public async Task Exemplo_1_APROVADO()
    {
        var (svc, pedidoSvc) = Build();
        await pedidoSvc.CreateAsync(PedidoPadrao(), CancellationToken.None);

        var res = await svc.AvaliarAsync(new("APROVADO", 3, 20m, "123456"), CancellationToken.None);
        Assert.Equal("123456", res.pedido);
        Assert.Equal(new[] { "APROVADO" }, res.status);
    }

    [Fact]
    public async Task Exemplo_2_APROVADO_VALOR_A_MENOR()
    {
        var (svc, pedidoSvc) = Build();
        await pedidoSvc.CreateAsync(PedidoPadrao(), CancellationToken.None);

        var res = await svc.AvaliarAsync(new("APROVADO", 3, 10m, "123456"), CancellationToken.None);
        Assert.Equal(new[] { "APROVADO_VALOR_A_MENOR" }, res.status);
    }

    [Fact]
    public async Task Exemplo_3_APROVADO_VALOR_A_MAIOR_e_QTD_A_MAIOR()
    {
        var (svc, pedidoSvc) = Build();
        await pedidoSvc.CreateAsync(PedidoPadrao(), CancellationToken.None);

        var res = await svc.AvaliarAsync(new("APROVADO", 4, 21m, "123456"), CancellationToken.None);
        Assert.Contains("APROVADO_VALOR_A_MAIOR", res.status);
        Assert.Contains("APROVADO_QTD_A_MAIOR", res.status);
        Assert.Equal(2, res.status.Count);
    }

    [Fact]
    public async Task Exemplo_4_APROVADO_QTD_A_MENOR()
    {
        var (svc, pedidoSvc) = Build();
        await pedidoSvc.CreateAsync(PedidoPadrao(), CancellationToken.None);

        var res = await svc.AvaliarAsync(new("APROVADO", 2, 20m, "123456"), CancellationToken.None);
        Assert.Equal(new[] { "APROVADO_QTD_A_MENOR" }, res.status);
    }

    [Fact]
    public async Task Exemplo_5_REPROVADO()
    {
        var (svc, pedidoSvc) = Build();
        await pedidoSvc.CreateAsync(PedidoPadrao(), CancellationToken.None);

        var res = await svc.AvaliarAsync(new("REPROVADO", 0, 0m, "123456"), CancellationToken.None);
        Assert.Equal(new[] { "REPROVADO" }, res.status);
    }

    [Fact]
    public async Task Exemplo_6_CODIGO_PEDIDO_INVALIDO()
    {
        var (svc, pedidoSvc) = Build();
        await pedidoSvc.CreateAsync(PedidoPadrao(), CancellationToken.None);

        var res = await svc.AvaliarAsync(new("APROVADO", 3, 20m, "123456-N"), CancellationToken.None);
        Assert.Equal(new[] { "CODIGO_PEDIDO_INVALIDO" }, res.status);
    }
}
